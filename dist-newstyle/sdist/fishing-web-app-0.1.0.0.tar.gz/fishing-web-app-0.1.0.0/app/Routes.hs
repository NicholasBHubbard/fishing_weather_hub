{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE QuasiQuotes #-}
{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE ViewPatterns #-}
{-# LANGUAGE MultiParamTypeClasses #-}

module Routes where

import Yesod
import Data.Text (Text) 
import Yesod.Form.Jquery

data Base = Base 
instance Yesod Base  

mkYesod
  "Base"
  [parseRoutes|
/ HomeR GET
/location LocationR POST
|]

instance RenderMessage Base FormMessage where
         renderMessage _ _ = defaultFormMessage

data Location = Location
    { city      :: Text
    , state     :: Text
    , country   :: Text
    }
    deriving (Show)

locationForm :: Html -> MForm Handler (FormResult Location, Widget)
locationForm = renderDivs $ Location
  <$> areq textField "City" Nothing
  <*> areq textField "State" Nothing
  <*> areq textField "Country" Nothing

 
postLocationR :: Handler Html
postLocationR = do 
  ((result, widget), enctype) <- runFormPost locationForm
  case result of
    FormSuccess loc -> defaultLayout [whamlet|<p>#{show loc}|]
    _ ->
      defaultLayout
      [whamlet|
          <p>Invalid Input, try again.
          <form method=post action=@{LocationR} enctype=#{enctype}>
              ^{widget}
              <button>Submit
      |]


getHomeR :: Handler Html    
getHomeR = do
  -- Generate the location form
  (widget, enctype) <- generateFormPost locationForm
  defaultLayout $ do
    [whamlet|
        <html>
        <header>
          <style>
            body{background-color: #ffcc66;}
          <center style="font-size:30px">Fishing Weather Hub
          <br>
          <form method=post action=@{LocationR} enctype=#{enctype}>
              ^{widget}
              <button>Submit
    |]
    toWidget
      [lucius|
        form {
        margin: 0 auto;
        width:250px;
        }
    |]
