{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE QuasiQuotes #-}
{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE TypeFamilies #-}

module FishSite where

import Yesod
import qualified Routes as R
 
runSite :: IO ()
runSite = warp 3000 R.Base

