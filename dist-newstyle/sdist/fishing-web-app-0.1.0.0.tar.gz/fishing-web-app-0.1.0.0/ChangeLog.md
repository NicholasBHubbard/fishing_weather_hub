# Changelog for fishing-web-app

## Unreleased changes
